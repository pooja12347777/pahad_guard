import streamlit as st


def require_login() -> bool:
    """Shows a 'Log in with Google' screen if the user isn't authenticated.

    Returns True once Streamlit's native auth confirms a logged-in Google
    user (st.user is populated automatically after st.login() completes
    the OAuth redirect). No passwords or OTP codes are handled by this app
    at all — Google verifies the user's identity.
    """
    if st.user.is_logged_in:
        return True

    st.title("🏔️ Pahad-Guard")
    st.subheader("Login required / लॉगिन आवश्यक है")
    st.caption(
        "Sign in with your Google account to access the risk dashboard "
        "and manage alert subscriptions."
    )
    st.button("🔐 Log in with Google", type="primary", on_click=st.login)

    return False


def render_logout_control() -> None:
    if not st.user.is_logged_in:
        return

    st.sidebar.markdown("---")
    name = st.user.get("name") or st.user.get("email", "user")
    st.sidebar.caption(f"Logged in as: {name}")
    if st.sidebar.button("Log out"):
        st.logout()


def current_user_email() -> str | None:
    if st.user.is_logged_in:
        return st.user.get("email")
    return None
